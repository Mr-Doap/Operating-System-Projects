This contains two .cpp files.Each file should be compiled using the following command.

g++ <filename> -o <name of executablefile>

And then we can run the file using the following command.

./<name of executablefile>
			
The results will be written in two files namely the Log and the stats file each contains the important details 
about the simulation.
