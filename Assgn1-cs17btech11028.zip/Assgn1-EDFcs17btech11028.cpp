#include <bits/stdc++.h>

using namespace std;

typedef struct Proc {  
	int proc_id;		
	int period;
	int proc_time_left;
	int max_no_of_left;
	int deadline;
	int isMissedDeadline;
	int missedDeadline;
	int wait_time;	
	int arri_time;
	int tot_proc_time;
} proc;

void EDF_scheduling(std::vector<proc*> &proc_vec,fstream &file2);
void EDF_running(std::vector<proc*> &proc_vec,proc* temp,int &clck,fstream &file2);
bool runningcondition(std::vector<proc*> &proc_vec);
bool check_preemption(std::vector<proc*> &proc_vec,proc* temp,int &clck,fstream &file2);
proc* next_event(std::vector<proc*> &proc_vec,int &clck);
void idle_time(std::vector<proc*> &proc_vec,int &clck,fstream &file2);
void update_proc_vec(proc* temp,int &clck);

proc* create_proc(int pid,int t,int p,int k){
	proc* temp=new proc;
	temp->proc_id=pid;temp->period=p;temp->proc_time_left=t;temp->max_no_of_left=k;
	temp->deadline=p;temp->isMissedDeadline=0;temp->missedDeadline=0;temp->wait_time=0;
	temp->arri_time=0;temp->tot_proc_time=t;
	return temp;
}

bool deadline_compare(proc *a,proc *b){
	if (a->deadline<b->deadline){
		return true;
	}
	return false;
}

int main(){
	fstream file1,file2,file3;
	string filename1,filename2,filename3;
	filename1="inp-params.txt";filename2="EDF-Log.txt";filename3="EDF-stats.txt";
	file1.open(filename1.c_str());
	file2.open(filename2,std::ios::out);
	file3.open(filename3,std::ios::out);
	std::vector<proc*> proc_vec;
	int n;
	file1>>n;
	int pid,t,p,k;int totproc=0;
	for(int i=0;i<n;i++){
		file1>>pid>>t>>p>>k;totproc+=k;
		file2<<"Process "<<pid<<": processing time="<<t<<"; deadline:"<<p<<"; period:"<<p<<" joined system at time 0"<<endl;
		proc* temp=create_proc(pid,t,p,k);
		proc_vec.push_back(temp);
	}
	EDF_scheduling(proc_vec,file2);
	int tot_missed_deadlines=0;float average_wait_time=0;
	for(int i=0;i<proc_vec.size();i++){
		if(proc_vec[i]->missedDeadline>=1){
			tot_missed_deadlines+=proc_vec[i]->missedDeadline;
		}
		average_wait_time+=proc_vec[i]->wait_time;
	}
	average_wait_time/=proc_vec.size();
	file3<<"The Total number of processes that came into the system are "<<totproc<<"."<<endl;
	file3<<"The Total number of processes that successfully completed are "<<totproc-tot_missed_deadlines<<"."<<endl;
	file3<<"The Total number of processes that missed their deadlines are "<<tot_missed_deadlines<<"."<<endl;
	file3<<"The average waiting time is "<<average_wait_time<<"."<<endl;
	file1.close();
	file2.close();
	file3.close();
}



void EDF_scheduling(std::vector<proc*> &proc_vec,fstream &file2){
	sort(proc_vec.begin(),proc_vec.end(),deadline_compare);
	proc* temp=proc_vec[0];int clck=0;
	file2<<"Process "<<temp->proc_id<<" starts execution at time "<<clck<<"."<<endl;
	EDF_running(proc_vec,temp,clck,file2);
	while(runningcondition(proc_vec)){
		temp=next_event(proc_vec,clck);
		if(temp){
			if(temp->proc_time_left!=temp->tot_proc_time){
				file2<<"Process "<<temp->proc_id<<" resumes execution at time "<<clck<<endl;
			}
			else{
				if(temp->arri_time==0){
					temp->wait_time=clck;
				}
			}
			EDF_running(proc_vec,temp,clck,file2);
		}
		else{
			idle_time(proc_vec,clck,file2);
		}
	}
}

void EDF_running(std::vector<proc*> &proc_vec,proc* temp,int &clck,fstream &file2){
	while(!check_preemption(proc_vec,temp,clck,file2)){
		temp->proc_time_left-=1;
		clck++;
		if(temp->proc_time_left==0){
			if(temp->deadline<clck){
				temp->isMissedDeadline=1;temp->missedDeadline+=1;
			}
			file2<<"Process "<<temp->proc_id<<" finishes execution at time "<<clck<<"."<<endl;
			update_proc_vec(temp,clck);
			sort(proc_vec.begin(),proc_vec.end(),deadline_compare);
			break;
		}
	}
}

bool runningcondition(std::vector<proc*> &proc_vec){
	for(int i=0;i<proc_vec.size();i++){
		if(proc_vec[i]->max_no_of_left>0){
			return true;
		}
	}
	return false;
}

bool check_preemption(std::vector<proc*> &proc_vec,proc* temp,int &clck,fstream &file2){
	proc* temp1=next_event(proc_vec,clck);
	if(temp1!=0){
		if(temp1->deadline<temp->deadline){
			file2<<"Process "<<temp->proc_id<<" is preempted by Process "<<temp1->proc_id<<" at time "<<clck<<".Remaining processing time:"<<temp->proc_time_left<<endl;
			return true;
		}
	}
	return false;
}

proc* next_event(std::vector<proc*> &proc_vec,int &clck){
	for(int i=0;i<proc_vec.size();i++){
		if(proc_vec[i]->arri_time<=clck && proc_vec[i]->max_no_of_left>0){
			return proc_vec[i];
		}
	}
	return 0;
}

void idle_time(std::vector<proc*> &proc_vec,int &clck,fstream &file2){
	std::vector<proc*> v;
	v=proc_vec;
	while(!next_event(v,clck)){
		clck++;
	}
	file2<<"CPU is idle till time "<<clck<<"."<<endl;
}

void update_proc_vec(proc* temp,int &clck){
	temp->arri_time+=temp->period;
	if (temp->isMissedDeadline){
		while (temp->arri_time<clck){
			temp->arri_time+=temp->period;
		}
	}
	temp->deadline=temp->arri_time+temp->period;
	temp->proc_time_left=temp->tot_proc_time;
	temp->max_no_of_left-=1;
	temp->isMissedDeadline=0;
}